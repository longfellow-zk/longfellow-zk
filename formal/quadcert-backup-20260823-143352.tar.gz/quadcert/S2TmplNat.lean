/-
# The `Nat` half of the wrapping-sum meaning

`S2TmplWrap` gives the field half: the assertion forces `wrapPoly n (2^32) z = 0`. Reaching the
arithmetic statement `P = C % 2^32` needs `SHA256F.wrap_sum_of_zero`'s other three hypotheses,
`z = C - P`, `C < n·2^32` and `P < 2^32`, and those are about the *addends* rather than the shape
of the product tree.

They are still template-uniform, and the reason is the coefficient structure. `z` is a flat linear
form `Σ 2^j · x_{a,j} - Σ 2^j · y_j` over input nodes that booleanity has already pinned to
`{0,1}`. So:

* the value of each half is the cast of a `Nat` -- `sum_of_bits`, proven once by induction;
* that `Nat` is bounded by the **sum of the coefficients**, which is data the generator has in
  hand. For 32-bit words `Σ_{j<32} 2^j = 2^32 - 1`, so `n` addend words give
  `C ≤ n(2^32 - 1) < n·2^32` and the output word gives `P ≤ 2^32 - 1 < 2^32`. The bounds are
  arithmetic on the coefficient list, not facts about the circuit.

What remains genuinely per-instance is only *which* inputs are addend bits and which are output
bits -- the split of `z`'s term list into the two halves. That is a fact about the layout, and it
enters below as `hz`.
-/

import Mathlib.Tactic.Ring
import SHA.Wrap

namespace SHA256F

variable {F : Type} [Field F]

/-- A linear form over field elements known to be bits is the cast of a `Nat`, bounded by the sum
    of its coefficients. Proven once; every wrapping-sum instance uses it twice. -/
theorem sum_of_bits :
    ∀ (l : List (Nat × F)), (∀ q ∈ l, q.2 = 0 ∨ q.2 = 1) →
      ∃ N : Nat, (l.map (fun q => (q.1 : F) * q.2)).sum = (N : F) ∧
        N ≤ (l.map Prod.fst).sum
  | [], _ => ⟨0, by simp, by simp⟩
  | q :: rest, h => by
      obtain ⟨N, hval, hbd⟩ := sum_of_bits rest (fun x hx => h x (List.mem_cons_of_mem _ hx))
      rcases h q (List.mem_cons_self ..) with hq | hq
      · refine ⟨N, ?_, ?_⟩
        · simp only [List.map_cons, List.sum_cons, hq, hval]; ring
        · simp only [List.map_cons, List.sum_cons]; omega
      · refine ⟨q.1 + N, ?_, ?_⟩
        · simp only [List.map_cons, List.sum_cons, hq, hval]; push_cast; ring
        · simp only [List.map_cons, List.sum_cons]; omega

/-- **The `Nat` half.** Booleanity of the addend and output bits, plus coefficient sums, turn the
    field-side product assertion into 32-bit arithmetic. -/
theorem wrap_nat_of_bits {p : Nat} [CharP F p] (n : Nat) (cs ds : List (Nat × F)) (z : F)
    (hc : ∀ q ∈ cs, q.2 = 0 ∨ q.2 = 1)
    (hd : ∀ q ∈ ds, q.2 = 0 ∨ q.2 = 1)
    (hcb : (cs.map Prod.fst).sum < n * 2 ^ 32)
    (hdb : (ds.map Prod.fst).sum < 2 ^ 32)
    (hnp : n * 2 ^ 32 ≤ p)
    (hz : z = (cs.map (fun q => (q.1 : F) * q.2)).sum
              - (ds.map (fun q => (q.1 : F) * q.2)).sum)
    (hroot : wrapPoly n ((2 ^ 32 : Nat) : F) z = 0) :
    ∃ C P : Nat,
      (cs.map (fun q => (q.1 : F) * q.2)).sum = (C : F) ∧
      (ds.map (fun q => (q.1 : F) * q.2)).sum = (P : F) ∧
      P = C % 2 ^ 32 := by
  obtain ⟨C, hCval, hCbd⟩ := sum_of_bits cs hc
  obtain ⟨P, hPval, hPbd⟩ := sum_of_bits ds hd
  refine ⟨C, P, hCval, hPval, ?_⟩
  exact wrap_sum_of_zero n C P z (lt_of_le_of_lt hCbd hcb) (lt_of_le_of_lt hPbd hdb) hnp
    (by rw [hz, hCval, hPval]) hroot

/-- The characteristic side condition, for the `n` the SHA-256 circuit actually uses. P-256's
    prime is 256 bits and `7 · 2^32 < 2^35`, so this is arithmetic, not an assumption. -/
theorem wrap_hnp (n : Nat) (hn : n ≤ 7) :
    n * 2 ^ 32 ≤ 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF := by
  have : n * 2 ^ 32 ≤ 7 * 2 ^ 32 := Nat.mul_le_mul_right _ hn
  omega

end SHA256F
